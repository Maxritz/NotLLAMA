#pragma once
#include "rdna4.hpp"
#include <string>
#include <vector>
#include <nlohmann/json.hpp>

namespace rdna4 {

class Tokenizer;

struct TensorDesc {
    std::string name;
    QuantFormat format;
    std::vector<uint32_t> shape;
    uint32_t nDims;
    size_t sizeBytes;
    size_t binOffset;
    size_t binSize;
    uint32_t blockSize;
    uint32_t blockElements;
    VkDeviceAddress gpuAddress;
    VkBuffer buffer;
    VkDeviceMemory memory;
};

struct ModelDesc {
    std::string architecture;
    uint32_t blockCount;
    uint32_t embeddingLength;
    uint32_t feedForwardLength;
    uint32_t headCount;
    uint32_t headCountKv;
    uint32_t headDim;       // actual head dim, derived from Q weight shape (not embeddingLength/headCount)
    uint32_t vocabSize;
    uint32_t contextLength;
    std::vector<TensorDesc> tensors;
};

class WeightUploader {
public:
    VkDevice device;
    VkPhysicalDevice physicalDevice;
    uint32_t queueFamilyIndex;

    WeightUploader(VkDevice dev, VkPhysicalDevice pdev, uint32_t qfi = 0)
        : device(dev), physicalDevice(pdev), queueFamilyIndex(qfi) {}

    ModelDesc load(const std::string& jsonPath, const std::string& binPath);
    ModelDesc loadMetadata(const std::string& jsonPath, const std::string& binPath);
    ModelDesc loadFromGGUF(const std::string& ggufPath, Tokenizer* tokenizer = nullptr);
    bool uploadTensor(TensorDesc& desc);
    bool uploadLayer(ModelDesc& model, uint32_t layerIndex);
    void loadTokenizer(Tokenizer& tokenizer, const nlohmann::json& tokenizerJson);
    void freeTensor(const TensorDesc& desc);
    void freeAll(ModelDesc& model);

private:
    std::vector<uint8_t> binData_;
    VkBuffer createGpuBuffer(size_t size, VkDeviceAddress* outAddr, VkDeviceMemory* outMem);
};

} // namespace rdna4
